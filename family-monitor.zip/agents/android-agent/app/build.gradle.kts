plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.family.monitor"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.family.monitor"
        minSdk = 24
        targetSdk = 34
        versionCode = 16
        versionName = "2.5.1"
    }

    signingConfigs {
        create("release") {
            storeFile = file("../family-monitor.keystore")
            storePassword = "familymonitor123"
            keyAlias = "family"
            keyPassword = "familymonitor123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        // لا نوقف البناء على تحذيرات Lint (الصلاحيات الخاصة مثل QUERY_ALL_PACKAGES)
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    // الفحص الاحتياطي الدوري الذي يستمر بعد إعادة تشغيل الجهاز
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
